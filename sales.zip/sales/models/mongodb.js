const mongoose = require('mongoose');
 
mongoose.connect('mongodb+srv://zoetidwell96:Morty2017@cluster0.dut3u.mongodb.net/myFirstDatabase?retryWrites=true&w=majority', {useNewUrlParser: true}, (err) => {
if (!err) {
console.log('Successfully Established Connection with MongoDB')
}
else {
console.log('Failed to Establish Connection with MongoDB with Error: '+ err)
}
});
 
//Connecting Node and MongoDB
require('./sales.model');

