const mongoose = require('mongoose');



//Attributes of the Sales object
var salesSchema = new mongoose.Schema({
	_id: {
	type: String },
	title: {
	type: String,
	required: 'This is required!'
	},
	price: {
	type: Number
	},
	units_sold: {
	type: Number
	},
   retail_price: {
    type: Number
    },
    ad_boost: {
    type: Number
    },
    rate_count: {
    type: Number
    },
    rating: {
    type: Number
    }
	});


mongoose.model('sales', salesSchema);








